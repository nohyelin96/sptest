package com.ez.herb.order.model;

public interface OrderService {

}
