package com.ez.herb.category.model;

import java.util.List;

public interface CategoryService {
	List<CategoryVO> selectCategory();
}
