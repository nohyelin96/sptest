package com.ez.herb.admin.manager.model;

public class AuthorityVO {

}
