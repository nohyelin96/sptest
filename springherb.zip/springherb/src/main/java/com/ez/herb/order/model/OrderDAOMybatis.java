package com.ez.herb.order.model;

public class OrderDAOMybatis {

}
