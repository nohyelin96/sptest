package com.ez.herb.category.model;

import java.util.List;

public interface CategoryDAO {
	List<CategoryVO> selectCategory();
	
}
