package com.ez.herb.event.model;

public interface EventProductDAO {
	int insertEventProduct(EventProductVO vo);
	int selectEventProductCount(EventProductVO vo);
	
	
}
